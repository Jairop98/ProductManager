import {useState} from "react";
import axios from "axios";

const Form = (props) => {
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    const onSubmitHandler = (e) => {
        e.preventDefault()

        const newProduct = {
            title,
            price,
            description
        };

        axios.post("http://localhost:8000/api/products", newProduct)
            .then(() => console.log("Creation successful on backend"))
            .catch((err) => console.log(err))
    };

    return (
        <div>
            <h1>Form component</h1>

            <form onSubmit={onSubmitHandler}>
                <div>
                    <label>Title</label>
                    <input 
                        onChange={(e) => setTitle(e.target.value)} 
                        type="text"
                    />
                </div>
                <div>
                    <label>Price</label>
                    <input 
                        onChange={(e) => setPrice(e.target.value)} 
                        type="number"
                        step="0.01"
                    />
                </div>
                <div>
                    <label>Description</label>
                    <input 
                        onChange={(e) => setDescription(e.target.value)} 
                        type="text"
                    />
                </div>
                <div>
                    <button>Submit</button>
                </div>
            </form>
        </div>
    );
};

export default Form;