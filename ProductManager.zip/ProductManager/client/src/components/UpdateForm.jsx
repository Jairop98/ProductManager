import {useState, useEffect} from "react";
import axios from "axios";
import {useParams} from "react-router-dom";

const UpdateForm = (props) => {
    const {id} = useParams();
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + id)
            .then(res => {
                setTitle(res.data.title)
                setPrice(res.data.price)
                setDescription(res.data.description)
            })
            .catch((err) => console.log("Something went wrong", err))
    }, [])
    const onSubmitHandler = (e) => {
        e.preventDefault()

        const newProduct = {
            title,
            price,
            description
        };

        axios.put("http://localhost:8000/api/products/" + id, newProduct)
            .then(() => console.log("Update successful on backend"))
            .catch((err) => console.log(err))
    };

    return (
        <div>
            <h1>Form component</h1>

            <form onSubmit={onSubmitHandler}>
                <div>
                    <label>Title</label>
                    <input 
                        onChange={(e) => setTitle(e.target.value)} 
                        type="text"
                        value={title}
                    />
                </div>
                <div>
                    <label>Price</label>
                    <input 
                        onChange={(e) => setPrice(e.target.value)} 
                        type="number"
                        step="0.01"
                        value={price}
                    />
                </div>
                <div>
                    <label>Description</label>
                    <input 
                        onChange={(e) => setDescription(e.target.value)} 
                        type="text"
                        value={description}
                    />
                </div>
                <div>
                    <button>Update</button>
                </div>
            </form>
        </div>
    );
};

export default UpdateForm;