import axios from "axios";
import {useState, useEffect} from "react";
import {Link} from "react-router-dom";

const DisplayList = (props) => {
    const [productList, setProductList] = useState([]);

    const deleteProduct = (productId) => {
        axios.delete("http://localhost:8000/api/products/" + productId)
            .then(() => { 
                console.log("Successfully deleted from the backend")
                removeFromDom(productId)
            })
            .catch((err) => console.log("Something went wrong", err))
    }

    const removeFromDom = (productId) => {
        setProductList(productList.filter(c => c._id !== productId))
    }

    useEffect(() => {
        axios
            .get("http://localhost:8000/api/products")
            .then((response) => setProductList(response.data))
            .catch((err) => console.log(err));
    }, [])
    return (
        <div>
            { productList.length > 0 && 
                productList.map((product, index) => ( 
                <>
                <Link to={"/products/" + product._id}><h1>{product.title}</h1></Link>
                <Link to={"/products/update/" + product._id}>Update</Link>
                <button onClick={() => deleteProduct(product._id)}>Delete</button>
                </>              
                ))
            }
        </div>
    );
};

export default DisplayList;