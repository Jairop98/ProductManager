import {Link} from "react-router-dom";

const Nav = () => {
    return (
        <div>
            <Link to={"/products/create"}>Add product</Link>
            <Link to={"/products"}>Display product</Link>
        </div>
    );
};

export default Nav;